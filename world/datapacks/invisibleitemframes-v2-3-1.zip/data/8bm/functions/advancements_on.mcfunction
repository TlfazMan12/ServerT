## Resets Advancement ##
## Called by: /function 8bm:advancements_on
## as Player / @s

## Score advancement switch - OFF
scoreboard players set 8bm.advoff 8bm.advswitch 0

## Revoke root trigger advancement
advancement revoke @a from 8bm:global/8bm.adv_remove

## Feedback to player who run command
tellraw @s ["",{"text":"8Bit Advancements ","color":"yellow"},{"text":"Enabled","color":"green"}]
