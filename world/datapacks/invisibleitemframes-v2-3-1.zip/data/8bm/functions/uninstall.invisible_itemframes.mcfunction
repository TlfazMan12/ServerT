## Remove Scoreboards, Clocks, Teams For Specified Pack ##
## Called by: /function 8bm:uninstall.*
## as Player / @s

## Uninstall feedback
tellraw @s [{"text":"- #InvisibleItemFrames Uninstalling","color":"gold"}]

## Remove
scoreboard objectives remove 8bm.iif.damage
scoreboard objectives remove 8bm.iif.distance
scoreboard objectives remove 8bm.iif.itemRot
scoreboard objectives remove 8bm.iif.itemRotX

## Add
scoreboard objectives add 8bm.uninstall dummy

## Check
execute store success score @s 8bm.uninstall run datapack disable "file/InvisibleItemFrames_v2.3.1.zip"

## File name changed
tellraw @s[scores={8bm.uninstall=0}] ["",{"text":" Default file name has been changed!","color":"red"},{"text":"\n"},{"text":" To complete uninstall please use the following command","color":"red"},{"text":"\n"},{"text":" /datapack disable \"file/<pack_name>\"","color":"aqua"}]

## Confirm
tellraw @s[scores={8bm.uninstall=1}] [{"text":"- DataPack Successfully Uninstalled","color":"green"}]

## Remove
scoreboard objectives remove 8bm.uninstall
