## Resets Advancement ##
## Called by: 8bm:global/triggers/8bm.adv_on
## as Player / @s

## Revoke root trigger advancement
advancement revoke @s from 8bm:global/triggers/8bm.adv_off
