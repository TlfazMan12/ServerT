## Conformation and Social Links ##
## Called by 8bm:*/pack_data/confirm_install
## as Server

tellraw @a[gamemode=creative] ["",{"text":"The8BitMonkey ","color":"gold"},{"text":"Data Packs","color":"dark_green"},{"text":"\n"},{"text":" If you experience any issues you can get in touch in the following ways!","color":"white"},{"text":"\n"},{"text":" [YouTube] ","color":"red","clickEvent":{"action":"open_url","value":"https://www.YouTube.com/The8BitMonkey"},"hoverEvent":{"action":"show_text","contents":[{"text":"https://www.YouTube.com/The8BitMonkey"}]}},{"text":"[Discord] ","color":"blue","clickEvent":{"action":"open_url","value":"http://www.The8BitMonkey.com/discord"},"hoverEvent":{"action":"show_text","contents":[{"text":"http://www.The8BitMonkey.com/discord"}]}},{"text":"[Twitter]","color":"aqua","clickEvent":{"action":"open_url","value":"https://Twitter.com/The8BitMonkey"},"hoverEvent":{"action":"show_text","contents":[{"text":"https://Twitter.com/The8BitMonkey"}]}},{"text":"\n"},{"text":"Installed Packs ---------------","color":"dark_green"}]

## Remove uninstall if previously installed
scoreboard objectives remove 8bm.uninstall
