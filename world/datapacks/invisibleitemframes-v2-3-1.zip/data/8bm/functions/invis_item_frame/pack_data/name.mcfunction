## Pack Name ##
## Called by: 8bm:*/pack_data/confirm_install
## as Server

tellraw @a[gamemode=creative] ["",{"text":">> Invisible Item Frames","color":"yellow"},{"text":" [Info]","color":"gold","clickEvent":{"action":"run_command","value":"/function 8bm:invis_item_frame/pack_data/info"},"hoverEvent":{"action":"show_text","contents":[{"text":"Click For Info"}]}}]
