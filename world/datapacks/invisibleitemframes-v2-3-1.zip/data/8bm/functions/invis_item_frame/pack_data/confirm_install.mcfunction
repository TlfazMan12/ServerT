## Run Social Links and Pack Name ##
## Called by: 8bm:*/advancement/8bm.invis_itemframes
## as Player

## Confirm pack installation
execute if entity @s[gamemode=creative] run schedule function 8bm:global/8bm.links 1s
execute if entity @s[gamemode=creative] run schedule function 8bm:invis_item_frame/pack_data/name 2s
