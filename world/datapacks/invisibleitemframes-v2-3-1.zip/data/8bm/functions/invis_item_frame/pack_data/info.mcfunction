## Detail information about the pack ##
## Called by: 8bm:*/pack_data/name
## as Player / @s

## Check feedback gamerule ##
scoreboard objectives add 8bm.feedback dummy
execute store result score 8bm.bool 8bm.feedback run gamerule sendCommandFeedback
execute unless score 8bm.bool 8bm.feedback matches 0 run gamerule sendCommandFeedback false
execute if score 8bm.bool 8bm.feedback matches 1 run schedule function 8bm:invis_item_frame/pack_data/command_feedback 1s
scoreboard objectives remove 8bm.feedback

## Pack info
tellraw @s[gamemode=creative] ["",{"text":"\n"},{"text":"Invisible Item Frames - info","color":"gold"},{"text":"\n"},{"text":"To create an invisible item frame:","color":"light_purple"},{"text":"\n"},{"text":" Press and hold crouch and right click on an item frame with a pair of shears."},{"text":"\n"},{"text":" The shears will become damaged with each use, a fresh pair of shears will be able to turn 20 item frames invisible."},{"text":"\n\n"},{"text":" However if they are enchanted with Unbreaking, this amount does increase:"},{"text":"\n"},{"text":" Unbreaking Level 1: ","color":"green"},{"text":"40 Item Frames","color":"red"},{"text":"\n"},{"text":" Unbreaking Level 2: ","color":"green"},{"text":"60 Item Frames","color":"red"},{"text":"\n"},{"text":" Unbreaking Level 3: ","color":"green"},{"text":"80 Item Frames","color":"red"},{"text":"\n"},{"text":"\n"},{"text":" When an affected item frame does NOT contain an item it will reappear and display soul particles to indicate that it has the ability to become invisible, when an item is then place back into it it will disappear once again."},{"text":"\n"},{"text":"\n"},{"text":"Rotation Lock: ","color":"light_purple"},{"text":"\n"},{"text":" To prevent accidental rotation of items due to not being able to see the hitbox when invisible, items will no longer rotate unless the player is holding shift while right clicking on it"},{"text":"\n"},{"text":" [ Uninstall Pack ]","color":"red","clickEvent":{"action":"run_command","value":"/function 8bm:uninstall.invisible_itemframes"}}]
