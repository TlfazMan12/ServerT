## Re-enable gamerule if it was originally true ##
## Called by: 8bm:*/pack_data/info
## as Server

## Enable
gamerule sendCommandFeedback true
