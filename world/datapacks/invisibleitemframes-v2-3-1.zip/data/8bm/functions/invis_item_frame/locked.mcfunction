## Start raycast at players face ##
## Called by: 8bm:/triggers/iif.lock_rotation
## as Player / @s

## Debug Command
execute if predicate 8bm:pack.debug run tellraw @a[tag=8bm.debug] [{"text":"- #ItemFrame Main","color":"aqua"}]

## Specifies item frame for commands to run off
execute as @s at @s anchored eyes positioned ^ ^ ^ anchored feet run function 8bm:invis_item_frame/raycast/start_ray

## Revoke advancement trigger
advancement revoke @s only 8bm:triggers/iif.lock_rotation
