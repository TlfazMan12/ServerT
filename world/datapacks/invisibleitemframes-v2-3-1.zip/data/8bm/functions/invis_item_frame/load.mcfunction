## Buffer function for potential future pack integration ##
## Called by: minecraft:load
## as Server

function 8bm:invis_item_frame/init
