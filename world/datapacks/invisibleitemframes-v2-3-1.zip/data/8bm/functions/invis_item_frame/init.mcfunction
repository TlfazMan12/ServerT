## Start pack installation conformation ##
## Called by: 8bm:*:load
## as Server

## Add pack scoreboards
scoreboard objectives add 8bm.iif.damage dummy
scoreboard objectives add 8bm.iif.distance dummy
scoreboard objectives add 8bm.iif.itemRot dummy
scoreboard objectives add 8bm.iif.itemRotX dummy

## Add scoreboard used to enable/disable advancements
scoreboard objectives add 8bm.advswitch dummy

## Start loops
function 8bm:invis_item_frame/state/loop
