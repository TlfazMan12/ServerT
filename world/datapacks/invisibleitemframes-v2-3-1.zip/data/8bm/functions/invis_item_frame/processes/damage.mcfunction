## Damage shears as they're used ##
## Called by: 8bm:*/state/process
## as Entity / @s

## Debug Command
execute if predicate 8bm:pack.debug run tellraw @a[tag=8bm.debug] [{"text":"- #ItemFrame Damage","color":"yellow"}]

## Damage shears
execute store result score @s 8bm.iif.damage run data get entity @s SelectedItem.tag.Damage
# NOT Enchanted (Unbreaking)
scoreboard players add @s 8bm.iif.damage 12
# Enchanted (Unbreaking)
scoreboard players remove @s[nbt={SelectedItem:{tag:{Enchantments:[{id:"minecraft:unbreaking",lvl:1s}]}}}] 8bm.iif.damage 6
scoreboard players remove @s[nbt={SelectedItem:{tag:{Enchantments:[{id:"minecraft:unbreaking",lvl:2s}]}}}] 8bm.iif.damage 8
scoreboard players remove @s[nbt={SelectedItem:{tag:{Enchantments:[{id:"minecraft:unbreaking",lvl:3s}]}}}] 8bm.iif.damage 9

## Store new damage value
execute store result storage 8bm:shear_damage Damage int 1 run scoreboard players get @s 8bm.iif.damage

## Add new damage to shears in-hand
item modify entity @s weapon.mainhand 8bm:iff.damagecalc

## End Of Life
execute as @s[scores={8bm.iif.damage=238..}] run item replace entity @s[nbt={SelectedItem:{id:"minecraft:shears"}}] weapon.mainhand with air
execute as @s[scores={8bm.iif.damage=238..}] at @s run playsound minecraft:item.shield.break player @a ~ ~ ~ .6
execute as @s[scores={8bm.iif.damage=238..}] at @s anchored eyes run particle minecraft:item minecraft:shears ^ ^ ^.25 0.1 0.1 0.1 0 10 normal

## Reset The Board
scoreboard players reset @s 8bm.iif.damage

## Remove Storage
data remove storage 8bm:shear_damage Damage
