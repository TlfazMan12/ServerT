## Turn item_frame invisible ##
## Called by: 8bm:*/state/process ## ## Called by:  8bm*/state/loop.nest1
## as/at Entity / @s

## Debug Command
execute if predicate 8bm:pack.debug run tellraw @a[tag=8bm.debug] [{"text":"- #ItemFrame Store","color":"yellow"}]

## Rotation Lock
execute store result score @s 8bm.iif.itemRot run data get entity @s ItemRotation
execute store result score @s 8bm.iif.itemRotX run data get entity @s ItemRotation
function 8bm:invis_item_frame/processes/rotation_locked
