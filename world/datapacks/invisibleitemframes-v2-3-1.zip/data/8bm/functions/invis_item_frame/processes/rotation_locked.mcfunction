## Turn item_frame invisible ##
## Called by: 8bm:*/state/process ## ## Called by:  8bm*/state/loop.nest1
## as/at Entity / @s

## Debug Command
execute if predicate 8bm:pack.debug run tellraw @a[tag=8bm.debug] [{"text":"- #ItemFrame Locked","color":"yellow"}]

## Rotation Lock
execute store result score @s 8bm.iif.itemRot run data get entity @s ItemRotation
execute unless score @s 8bm.iif.itemRot = @s 8bm.iif.itemRotX run scoreboard players remove @s 8bm.iif.itemRot 1
execute store result entity @s ItemRotation int 1 run scoreboard players get @s 8bm.iif.itemRot
scoreboard players reset @s 8bm.iif.itemRot
execute store result score @s 8bm.iif.itemRotX run data get entity @s ItemRotation
