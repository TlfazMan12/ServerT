## Run functions off marked item_frame ##
## Called by: 8bm:*/processes/raycast
## as Entity / @s

## Debug Command
execute if predicate 8bm:pack.debug run tellraw @a[tag=8bm.debug] [{"text":"- #ItemFrame Process","color":"yellow"}]

## Process item_frame for invisiblity
function 8bm:invis_item_frame/state/invisible

## Rotation Lock
execute if entity @s[tag=8bm.invisframe.target] run function 8bm:invis_item_frame/processes/rotation_locked
