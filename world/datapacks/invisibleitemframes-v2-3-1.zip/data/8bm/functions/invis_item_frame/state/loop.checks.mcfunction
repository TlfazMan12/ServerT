## Check state requirement ##
## Called by: 8bm:*/state/loop
## as/at Entity / @s

## Debug Command
execute if predicate 8bm:pack.debug run tellraw @a[tag=8bm.debug,tag=8bm.loops] [{"text":"- #ItemFrame loop.nest1","color":"red"}]

## Affected Item Frame Indicator
execute at @s[nbt=!{Item:{}}] run particle minecraft:soul ^ ^ ^.1 0 0 0 0 1 normal

## Make Invisible
execute if entity @s[tag=!8bm.invisframe.processed,nbt={Item:{}}] run function 8bm:invis_item_frame/state/invisible

## Make Visible
execute if entity @s[tag=8bm.invisframe.processed,nbt=!{Item:{}}] run function 8bm:invis_item_frame/state/visible
