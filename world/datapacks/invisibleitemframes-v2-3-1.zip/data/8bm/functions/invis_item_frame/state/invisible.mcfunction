## Turn item_frame invisible ##
## Called by: 8bm:*/state/process ## ## Called by:  8bm*/state/loop.checks
## as/at Entity / @s

## Debug Command
execute if predicate 8bm:pack.debug run tellraw @a[tag=8bm.debug] [{"text":"- #ItemFrame Invisible","color":"yellow"}]

## Modify item_frame NBT
data modify entity @s Invisible set value 1b

## Playsound and Particles at Item_Frame location
execute at @s run playsound minecraft:entity.item_frame.remove_item master @a ~ ~ ~ .3
execute at @s run particle minecraft:poof ^ ^ ^.2 0 0 0 .001 6 normal
execute at @s[tag=!8bm.invisframe.target] run particle minecraft:item item_frame ^ ^ ^.1 .2 .2 .2 .001 25 normal

## Tag item_frame
tag @s add 8bm.invisframe.processed
tag @s add 8bm.invisframe.target
