## Turn item_frame visible ##
## Called by: 8bm:*/state/loop.checks
## as/at Entity / @s

## Debug Command
execute if predicate 8bm:pack.debug run tellraw @a[tag=debug] [{"text":"- #ItemFrame Visible","color":"yellow"}]

## Modify item_frame NBT
data modify entity @s Invisible set value 0b

## Playsound and Particles at Item_Frame location
execute at @s run playsound minecraft:entity.item_frame.remove_item master @a ~ ~ ~ .3
execute at @s run particle minecraft:poof ^ ^ ^.2 0 0 0 .001 6 normal

## Remove tag
tag @s remove 8bm.invisframe.processed
