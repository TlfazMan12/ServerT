## Loop - check for item_frame ##
## Called by: 8bm:*/init
## as Server

## Debug Command
execute if predicate 8bm:pack.debug run tellraw @a[tag=8bm.debug,tag=8bm.loops] [{"text":"- #ItemFrame loop","color":"red"}]

## Find and target item_frame
execute at @a as @e[type=#8bm:iif.item_frames,tag=8bm.invisframe.target,distance=..25] at @s run function 8bm:invis_item_frame/state/loop.checks

## Loop function
schedule function 8bm:invis_item_frame/state/loop 2s
