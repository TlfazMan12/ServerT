## Gives reward for completing the reqirements ##
## Called by: 8bm:advancement/iif.so_predictable
## as Player / @s

## Summon snowball at item_frame
execute at @e[type=#8bm:iif.item_frames,nbt={Item:{id:"minecraft:player_head",tag:{SkullOwner: {Properties: {textures: [{Value: "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZGQ1YjJkZDFlYzVhOWNkODgyMjdhN2ZiNTNhMGFkYjBiM2Q5YjBkYzVkNDhmN2U3NzQwM2U1NzhjZTBiMDhhOCJ9fX0="}]}}}}},distance=..10,limit=1,sort=nearest] run summon minecraft:snowball ~ ~.7 ~ {Item:{id:"minecraft:oak_button",Count:1b},Motion:[0.0d,-1.0d,0.0d]}

## Play particles at item_frame
execute at @e[type=#8bm:iif.item_frames,nbt={Item:{id:"minecraft:player_head",tag:{SkullOwner: {Properties: {textures: [{Value: "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZGQ1YjJkZDFlYzVhOWNkODgyMjdhN2ZiNTNhMGFkYjBiM2Q5YjBkYzVkNDhmN2U3NzQwM2U1NzhjZTBiMDhhOCJ9fX0="}]}}}}},distance=..10,limit=1,sort=nearest] run particle minecraft:item stripped_oak_wood ^ ^ ^.2 0.2 0.2 0.2 0 10 force

## Add xp
xp add @s 50 points
