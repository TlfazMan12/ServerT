## Gives reward for completing the reqirements ##
## Called by: 8bm:advancement/iif.frameception
## as Player / @s

## Give player pack trophy
give @s player_head{display:{Name:'{"text":"FrameCeption","italic":false}',Lore:['{"text":"Now that\'s thinking outside","color":"aqua","italic":false}','{"text":"of the box...or inside","color":"aqua","italic":false}','{"text":"of the frame","color":"aqua","italic":false}','{"text":"-"}','{"text":"Advancement Trophy","color":"red","italic":false}']},SkullOwner:{Id:[I;-390646606,1175077011,-1842496331,-1475032655],Name:'FrameCeption',Properties:{textures:[{Value:"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZGQ1YjJkZDFlYzVhOWNkODgyMjdhN2ZiNTNhMGFkYjBiM2Q5YjBkYzVkNDhmN2U3NzQwM2U1NzhjZTBiMDhhOCJ9fX0="}]}}} 1

## Add xp
xp add @s 100 points
