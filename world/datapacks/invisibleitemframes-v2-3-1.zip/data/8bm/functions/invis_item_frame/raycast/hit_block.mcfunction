## Raycast ##
## Called by: 8bm:*/raycast/ray
## Raycast Code by: Vdvman1

## Debug Command
execute if predicate 8bm:pack.debug run tellraw @a[tag=8bm.debug] [{"text":"- #ItemFrame Blocked","color":"dark_red"}]

## Score fake player if block from list is found
scoreboard players set #hit 8bm.iif.distance 1
