## Start Raycast ##
## Called by: 8bm:*/main & rot_locked
## as/at player / @s
## Raycast Code by: Vdvman1

## Debug Command
execute if predicate 8bm:pack.debug run tellraw @a[tag=8bm.debug] [{"text":"- #ItemFrame StartCast","color":"yellow"}]

## Reset distance and hit score
scoreboard players set #hit 8bm.iif.distance 0
scoreboard players set #distance 8bm.iif.distance 0

## Run raycast
function 8bm:invis_item_frame/raycast/ray
