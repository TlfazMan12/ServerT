## Raycast ##
## Called by: 8bm:*/raycast/start_ray
## as/at player / @s
## Raycast Code by: Vdvman1

## Debug Command
execute if predicate 8bm:pack.debug run tellraw @a[tag=8bm.debug] [{"text":"- #ItemFrame Ray","color":"green"}]

## Detect item_frame for functions to run off
execute if score #hit 8bm.iif.distance matches 0 positioned ~-0.05 ~-0.05 ~-0.05 as @e[type=#8bm:iif.item_frames,dx=0,sort=nearest] run function 8bm:invis_item_frame/raycast/check_hit_entity

## Stop cast if block found from list
execute unless block ~ ~ ~ #8bm:raycast run function 8bm:invis_item_frame/raycast/hit_block

## Add distance score to fake players
scoreboard players add #distance 8bm.iif.distance 1

## Repeat ray function until score matches X
execute if score #hit 8bm.iif.distance matches 0 if score #distance 8bm.iif.distance matches ..50 positioned ^ ^ ^0.1 run function 8bm:invis_item_frame/raycast/ray
