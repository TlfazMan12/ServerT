## Entity hit ##
## Called by: 8bm:*/raycast/ray
## as/at Entity / @s
## Raycast Code by: Vdvman1

## Debug Command
execute if predicate 8bm:pack.debug run tellraw @a[tag=8bm.debug] [{"text":"- #ItemFrame Hit","color":"red"}]

## Score fake player if entity hit
scoreboard players set #hit 8bm.iif.distance 1

## Run function if item_frame is already invisible
execute unless entity @a[advancements={8bm:triggers/iif.item_move=true},distance=..6] if entity @s[tag=8bm.invisframe.target] run function 8bm:invis_item_frame/processes/rotation_locked

## Run function if item_frame is already invisible
execute if entity @s[tag=8bm.invisframe.target] run function 8bm:invis_item_frame/processes/rotation_store

## Run function if item_frame hasn't been sheared yet
execute if entity @s[tag=!8bm.invisframe.target] run function 8bm:invis_item_frame/state/process
