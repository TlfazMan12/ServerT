## Raycast ##
## Called by: 8bm:*/raycast/ray
## as/at Entity / @s
## Raycast Code by: Vdvman1

## Debug Command
execute if predicate 8bm:pack.debug run tellraw @a[tag=8bm.debug] [{"text":"- #ItemFrame Check_Hit","color":"white"}]

## Confirm entity has been found
execute if score #hit 8bm.iif.distance matches 0 positioned ~-0.9 ~-0.9 ~-0.9 if entity @s[dx=0] positioned ~0.95 ~0.95 ~0.95 run function 8bm:invis_item_frame/raycast/hit_entity
