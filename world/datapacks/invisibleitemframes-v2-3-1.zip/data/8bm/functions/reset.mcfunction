## Resets Advancement Triggers if one stops working correctly ##
## Called by: /function 8bm:reset
## as Player / @s

## Revoke root trigger advancement
advancement revoke @a through 8bm:global/triggers/global.reset
advancement revoke @a from global:the8bitmonkey

## Feedback to player who run command
tellraw @s ["",{"text":" Pack now reset, this does NOT affect the Advancements you have gained from the pack!","color":"green"}]
